<?php

namespace WPDataAccess\Settings;

class WPDA_Settings_PDS extends WPDA_Settings
{
    protected function add_content()
    {
    }

}