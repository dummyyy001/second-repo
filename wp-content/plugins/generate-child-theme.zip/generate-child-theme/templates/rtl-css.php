/*
Theme Name:     <?php echo $theme_name, "\n"; ?>
Template:       <?php echo $parent_theme_template, "\n"; ?>

This is the child theme for <?php echo $parent_theme_name; ?> theme, generated with Generate Child Theme plugin by catchthemes.

Right to Left text support.
*/
@import url("../<?php echo $rtl_theme; ?>/rtl.css");
