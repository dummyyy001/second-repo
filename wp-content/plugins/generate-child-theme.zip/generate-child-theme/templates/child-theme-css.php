/*
Theme Name: <?php echo $theme_name, "\n"; ?>
Author: <?php echo $author, "\n"; ?>
Description: <?php echo $description, "\n"; ?>
Version: <?php echo $version, "\n"; ?>
Template: <?php echo $parent_theme_template, "\n"; ?>

This is the child theme for <?php echo $parent_theme_name; ?> theme, generated with Generate Child Theme plugin by catchthemes.

(optional values you can add: Theme URI, Author URI, License, License URI, Tags, Text Domain)
*/
